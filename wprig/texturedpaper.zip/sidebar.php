<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package texturedpaper
 */

namespace WP_Rig\WP_Rig;

if ( ! texturedpaper()->is_primary_sidebar_active() ) {
	return;
}

texturedpaper()->print_styles( 'texturedpaper-sidebar', 'texturedpaper-widgets' );

?>
<aside id="secondary" class="primary-sidebar widget-area">
	<?php texturedpaper()->display_primary_sidebar(); ?>
</aside><!-- #secondary -->
